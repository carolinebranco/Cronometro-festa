var timerDisplay = document.getElementById('timer');
var buyTicketButton = document.getElementById('buy-ticket-btn');

function startTimer() {
  var sixtyHoursInSeconds = 60 * 60 * 60; // 60 horas em segundos
  var countdownDate = Date.now() + sixtyHoursInSeconds * 1000;

  var timerInterval = setInterval(function() {
    var now = Date.now();
    var distance = countdownDate - now;

    if (distance <= 0) {
      clearInterval(timerInterval);
      timerDisplay.textContent = "00:00:00";
      return;
    }

    var hours = Math.floor(distance / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

    timerDisplay.textContent = padZero(hours) + ":" + padZero(minutes) + ":" + padZero(seconds);
  }, 1000);
}

function padZero(number) {
  return number.toString().padStart(2, '0');
}

function buyTicket() {
  console.log('Ingresso comprado! Divirta-se na festa!');
}

startTimer();
buyTicketButton.addEventListener('click', buyTicket);